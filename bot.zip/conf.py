import pymysql

class MySQL:

    def __init__(self):
        self.connect = pymysql.connect(host="87.249.38.253",
                                       user="cl14735_default",
                                       password="p9Sybyd7",
                                       db="cl14735_default",
                                       charset='utf8mb4',
                                       cursorclass=pymysql.cursors.Cursor)
        self.cursors = self.connect.cursor()
        self.connect.commit()

    def get_data(self):
        self.cursors.execute("SELECT * FROM `bullclub_data`")
        data_list = self.cursors.fetchall()
        ret_data = []
        for data in data_list:
            ret_data_dict = {"id": data[0],'wallet': data[1], "secret": data[2]}
            ret_data.append(ret_data_dict)
        return ret_data
    
    def delete_data(self, id):
        text = "DELETE FROM `bullclub_data` WHERE `id` = %s"
        data = (id)
        self.cursors.execute(text, data)
        self.connect.commit()

print(MySQL().get_data())

TOKEN = "5039332441:AAG59mkJKaUuqSB9DruJp0CYuFXC9NpYNyc"